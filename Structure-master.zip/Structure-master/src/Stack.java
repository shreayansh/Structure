package stack;

import java.net.SocketOption;

public class Stack
{
    int size;
    int top;
    int[] stackarray;

    public MyStack(int size)
    {
        this.size=size;
        top=-1;
        stackarray=new int[size];
    }
    public void push(int x)
    {
        if (!isFull()) {
            top++;
            stackarray[top] = x;
        }
    }
    public int pop()
    {
        if(!isEmpty())
        {
            stackarray[top]=0;
            top--;
        }
        return stackarray[top--];
    }
    public boolean isFull()
    {
        if(stackarray[stackarray.length-1]!=0 && top==stackarray.length-1)
            return true;
        else
            return false;
    }
    public boolean isEmpty()
    {
        if (top == -1)
            return true;
        else
            return false;

    }
    public void display()
    {
        for (int length = stackarray.length-1; length >= 0; length--)
        {
            System.out.println(stackarray[length]);

        }
    }
}
