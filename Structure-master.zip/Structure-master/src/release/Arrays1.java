package release;

import java.util.Arrays;

public class Arrays1
{
    public static void main(String[] args) {
        //int, float, double, char, long,
        //short, byte, boolean
        //char c;
        float[] arr = new float[10];
        System.out.println(arr[0]);
        String[] sarr = new String[10];
        System.out.println(sarr[0]);

        Object[] oarr = new Object[10];
    }
}
