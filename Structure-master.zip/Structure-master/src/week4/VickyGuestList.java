package week4;

import java.sql.SQLOutput;
import java.util.Arrays;

public class VickyGuestList
{

    private Guest[] guestsArray;
    private int last;

    public VickyGuestList(int numberOfGuests)
    {
        guestsArray = new Guest[numberOfGuests];
        last = -1;
    }

    public void insert(Guest guest)
    {
        if (last)
    }

    public static void main(String[] args) {
        VickyGuestList list = new VickyGuestList();
        System.out.println(Arrays.toString());
    }
}

class MyGuest
{
    private int guestNum;
    private String guestName;

    // getter
    int getGuestNum()
    {
        return guestNum;
    }
    // setter
    void setGuestNum(int guestNum)
    {
        this.guestNum = guestNum;
    }

    public String getGuestName() {
        return guestName;
    }
}
