public class MyStack
{
    int size;
    int top;
    int stackarray [];

    public MyStack()
    {
        size = 10;
        top = -1;
        stackarray = new int[size];
    }
}
